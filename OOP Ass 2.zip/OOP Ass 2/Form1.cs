using System;
using System.Collections.Generic;
using System.IO;
using System.Windows.Forms;
using Newtonsoft.Json;

namespace OOP_Ass_2
{
    public partial class Form1 : Form
    {
        private List<Identity> identities = new List<Identity>();

        public Form1()
        {
            InitializeComponent();
            LoadUsersFromJson("users.json"); 
        }

        private void LoadUsersFromJson(string filePath)
        {
            string fullPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, filePath);
            if (File.Exists(fullPath))
            {
                try
                {
                    string jsonData = File.ReadAllText(fullPath);
                    identities = JsonConvert.DeserializeObject<List<Identity>>(jsonData) ?? new List<Identity>();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error loading user data: " + ex.Message);
                }
            }
            else
            {
                MessageBox.Show("User data file not found.");
            }
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            string username = txtUsername.Text.Trim();
            string password = txtPassword.Text.Trim();

            if (IsValid(username, password))
            {
                lblMessage.Text = "Login successful!";
                
            }
            else
            {
                lblMessage.Text = "Invalid username or password.";
            }
        }

        private bool IsValid(string username, string password)
        {
            foreach (Identity identity in identities)
            {
                if (identity.Username.Equals(username, StringComparison.OrdinalIgnoreCase) &&
                    identity.Password == password)
                {
                    return true;
                }
            }
            return false;
        }
    }

    public class Identity
    {
        public string Username { get; set; } = string.Empty; 
        public string Password { get; set; } = string.Empty; 
    }
}
